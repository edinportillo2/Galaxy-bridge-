'use strict';
const el = id => document.getElementById(id);
const search = el('search'), disconnect = el('disconnect');
let device = null, server = null, busy = false;
const KEY = 'galaxy-bridge-1.5-log';
let entries = [];
try { const saved = JSON.parse(localStorage.getItem(KEY) || '[]'); if (Array.isArray(saved)) entries = saved.filter(v => typeof v === 'string').slice(-100); } catch (_) {}
function renderLog() { el('log').textContent = entries.slice().reverse().join('\n') || 'Sin pruebas registradas.'; }
function log(message) { entries.push('[' + new Date().toLocaleString('es') + '] ' + message); entries = entries.slice(-100); try { localStorage.setItem(KEY, JSON.stringify(entries)); } catch (_) {} renderLog(); }
function status(message) { el('status').textContent = message; log(message); }
function compatibility() { if (!window.isSecureContext) return 'Se requiere HTTPS.'; if (!navigator.bluetooth || typeof navigator.bluetooth.requestDevice !== 'function') return 'Web Bluetooth no está disponible en este navegador. En iPhone/Safari no funciona.'; return null; }
function updateSupport() { const error = compatibility(); el('support').textContent = error || 'Web Bluetooth disponible en este navegador.'; search.disabled = !!error || busy; }
function identify(name) { if (/galaxy\s*watch\s*active\s*2/i.test(name)) return 'Posible Galaxy Watch Active2 (según nombre anunciado; no verificado)'; if (/galaxy\s*watch\s*8/i.test(name)) return 'Posible Galaxy Watch 8 (según nombre anunciado; no verificado)'; if (/galaxy\s*watch/i.test(name)) return 'Posible Galaxy Watch (modelo no confirmado)'; return 'No identificado; el nombre BLE no verifica el modelo'; }
function resetDetails() { el('device').textContent = 'Ninguno'; el('model').textContent = 'Modelo: pendiente'; el('battery').textContent = 'Batería: no disponible'; el('services').replaceChildren(); const li = document.createElement('li'); li.textContent = 'Sin datos.'; el('services').append(li); }
function onDisconnected() { server = null; disconnect.disabled = true; status('Dispositivo desconectado.'); }
async function connect() {
 if (busy) return;
 const error = compatibility(); if (error) { status(error); return; }
 busy = true; updateSupport();
 try {
  status('Abriendo selector Bluetooth…');
  const chosen = await navigator.bluetooth.requestDevice({acceptAllDevices:true, optionalServices:['battery_service','device_information']});
  if (device) device.removeEventListener('gattserverdisconnected', onDisconnected);
  device = chosen; device.addEventListener('gattserverdisconnected', onDisconnected);
  const name = device.name || 'Sin nombre';
  el('device').textContent = name;
  el('model').textContent = 'Modelo: ' + identify(name);
  el('battery').textContent = 'Batería: no disponible';
  el('services').replaceChildren();
  log('Dispositivo seleccionado: ' + name + '.');
  status('Intentando conexión GATT…');
  server = await device.gatt.connect();
  disconnect.disabled = false;
  status('Conexión GATT establecida (no implica emparejamiento con Galaxy Watch).');
  let services = [];
  try { services = await server.getPrimaryServices(); } catch (err) { log('No se pudieron enumerar servicios: ' + (err.message || err.name)); }
  if (services.length) { for (const svc of services) { const li = document.createElement('li'); li.textContent = svc.uuid; el('services').append(li); } log('Servicios accesibles: ' + services.length); }
  else { const li = document.createElement('li'); li.textContent = 'No se encontraron servicios accesibles con los permisos actuales.'; el('services').append(li); }
  try { const svc = await server.getPrimaryService('battery_service'); const characteristic = await svc.getCharacteristic('battery_level'); const value = await characteristic.readValue(); const level = value.getUint8(0); el('battery').textContent = 'Batería: ' + level + '%'; log('Batería estándar: ' + level + '%'); }
  catch (err) { log('Batería estándar no accesible: ' + (err.message || err.name)); }
 } catch (err) { const cancelled = err.name === 'NotFoundError'; status(cancelled ? 'No se seleccionó ningún dispositivo o se canceló la búsqueda.' : 'Error Bluetooth: ' + (err.message || err.name)); }
 finally { busy = false; updateSupport(); disconnect.disabled = !(server && server.connected); }
}
search.addEventListener('click', connect);
disconnect.addEventListener('click', () => { if (device && device.gatt && device.gatt.connected) device.gatt.disconnect(); else onDisconnected(); });
el('clear').addEventListener('click', () => { entries = []; try { localStorage.removeItem(KEY); } catch (_) {} renderLog(); });
el('export').addEventListener('click', () => { const blob = new Blob([entries.join('\n') + '\n'], {type:'text/plain;charset=utf-8'}); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'galaxy-bridge-registro-1.5.txt'; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); });
resetDetails(); renderLog(); updateSupport(); log('Galaxy Bridge 1.5 iniciado.');
