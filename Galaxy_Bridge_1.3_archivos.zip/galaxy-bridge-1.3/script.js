const scan = document.getElementById('scan');
const status = document.getElementById('status');
function message(text) { status.textContent = text; }
scan.addEventListener('click', async () => {
  if (!window.isSecureContext) {
    message('Esta página debe abrirse mediante HTTPS o localhost para usar Bluetooth.');
    return;
  }
  if (!navigator.bluetooth || typeof navigator.bluetooth.requestDevice !== 'function') {
    message('Este navegador no permite buscar dispositivos con Web Bluetooth. En iPhone/iPad Safari no está disponible. Prueba Chrome en Android para una exploración experimental.');
    return;
  }
  scan.disabled = true;
  message('Abriendo el selector Bluetooth del navegador…');
  try {
    const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: [] });
    message('Dispositivo seleccionado: ' + (device.name || 'Sin nombre') + '. Esto solo confirma que el navegador lo detectó; NO significa que Galaxy Watch esté emparejado ni que sus funciones estén disponibles.');
  } catch (error) {
    if (error.name === 'NotFoundError') message('No seleccionaste ningún dispositivo o no se encontró uno compatible. Comprueba Bluetooth y vuelve a intentar.');
    else if (error.name === 'SecurityError') message('El navegador bloqueó el acceso a Bluetooth por permisos o seguridad.');
    else message('No fue posible buscar dispositivos: ' + (error.message || error.name));
  } finally { scan.disabled = false; }
});
