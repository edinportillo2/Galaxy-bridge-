# Galaxy Bridge 1.3 — prototipo web

Proyecto experimental para explorar las posibilidades de conexión entre Galaxy Watch 8 e iPhone. **No es una aplicación iOS instalada, un archivo IPA ni una solución de emparejamiento funcional.**

## Archivos
- `index.html`: interfaz en español.
- `style.css`: identidad azul oscuro / azul eléctrico.
- `script.js`: botón de búsqueda con Web Bluetooth y manejo de errores.

## Cómo probar
1. Sube **los cuatro archivos** a la raíz del repositorio GitHub (extrae el ZIP primero).
2. En Settings → Pages, configura Deploy from a branch, rama `main`, carpeta `/ (root)` y guarda.
3. Abre la dirección HTTPS publicada por GitHub Pages en Chrome para Android.
4. Pulsa «Buscar dispositivos» y revisa el resultado. Es posible que Galaxy Watch 8 no aparezca.

## Limitaciones
- Safari en iPhone/iPad no admite Web Bluetooth; esta versión web no puede buscar el reloj allí.
- La detección BLE no equivale a emparejamiento, llamadas, mensajes, notificaciones ni sincronización de salud.
- Para una aplicación iOS real haría falta desarrollar y probar una app nativa con Core Bluetooth y estudiar las restricciones de protocolo del reloj.
- Este prototipo no recoge ni transmite datos.
